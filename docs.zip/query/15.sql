CREATE PROCEDURE query15(isbn char(13))

SELECT s.frase, s.data_modifica, s.utente
 FROM Storia s
 WHERE s.pubblicazione=isbn;
