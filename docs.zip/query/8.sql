CREATE PROCEDURE query8(isbn_ char(13), titolo char(128), autore_ integer, parola_chiave char(128))

SELECT DISTINCT p.*
FROM Pubblicazione p
RIGHT JOIN Autore_Pubblicazione ap ON ap.pubblicazione=p.isbn
RIGHT JOIN Keywords k ON k.pubblicazione=p.isbn
WHERE p.isbn=isbn_ OR p.titolo=titolo OR ap.autore=autore_ OR k.parola=parola_chiave;
