DELIMITER //

CREATE FUNCTION is_mod(moderatore char(128)) RETURNS int DETERMINISTIC
BEGIN
DECLARE is_mod integer;
SELECT COUNT(*) into is_mod FROM Utente WHERE username=moderatore AND tipologia=2;
RETURN is_mod;
END
//

DELIMITER;
