CREATE PROCEDURE query9(pubblicazione char(13), username char(128), mi_piace tinyint(1), descrizione char(255))
INSERT INTO Recensione (pubblicazione, utente, mi_piace, descrizione) VALUES (pubblicazione, username, mi_piace, descrizione);
