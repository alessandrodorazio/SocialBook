CREATE PROCEDURE Registrazione (email char(128), password char(128))
INSERT INTO Utente (username, email, password) VALUES (email,email,PASSWORD(password));
