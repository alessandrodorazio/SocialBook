CREATE PROCEDURE QUERY7(isbn_ char(13))

SELECT DISTINCT p.*, nome_editore, autori, sorgenti, indici, ristampe, parole_chiave
FROM Pubblicazione p,
(SELECT group_concat(concat(a.nome," ",a.cognome)) AS autori FROM Autore a,Autore_Pubblicazione ap WHERE ap.pubblicazione=isbn_ AND ap.autore=a.id) s1,

(SELECT group_concat(concat(s.tipo,":",s.uri,":",s.formato,":",s.descrizione)) AS sorgenti FROM Sorgente s WHERE s.pubblicazione=isbn_) s2,

(SELECT group_concat(concat(i.numero,":",i.titolo)) AS indici FROM Indice i WHERE i.pubblicazione=isbn_) s3  ,

(SELECT group_concat(concat(r.data_ristampa,":",r.numero)) AS ristampe FROM Ristampe r WHERE r.pubblicazione=isbn_) s4,

(SELECT group_concat(k.parola) AS parole_chiave FROM Keywords k WHERE k.pubblicazione=isbn_) s5,

(SELECT e.nome AS nome_editore FROM Editore e, Pubblicazione p WHERE p.editore=e.id AND p.isbn=isbn_) s6

WHERE p.isbn=isbn_;
