CREATE PROCEDURE query12(pubblicazione char(13))

SELECT COUNT(*) AS n_like
FROM Recensione r, Pubblicazione p
WHERE r.mi_piace=TRUE AND r.pubblicazione=p.isbn AND p.isbn=pubblicazione
