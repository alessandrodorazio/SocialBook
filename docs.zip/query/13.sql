CREATE PROCEDURE query13(isbn char(13))

SELECT mi_piace,descrizione, utente, data_inserimento
 FROM Recensione 
WHERE pubblicazione=isbn AND approvata=TRUE;
