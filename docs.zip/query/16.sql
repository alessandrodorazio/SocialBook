CREATE PROCEDURE query16()

SELECT p.isbn, p.titolo
FROM Pubblicazione p, Sorgente s
 WHERE s.pubblicazione=p.isbn AND s.tipo="Download";
