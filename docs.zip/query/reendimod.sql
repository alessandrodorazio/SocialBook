CREATE PROCEDURE rendimod(utente char(128))
UPDATE Utente SET tipo=2 WHERE username=utente;
