CREATE PROCEDURE recensioni_utente(user char(128))
SELECT *
FROM Recensione r
WHERE r.utente=user;
