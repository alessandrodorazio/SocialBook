CREATE PROCEDURE query1(user char(128), user_mod char(128), tipo int)
UPDATE Utente u1
SET u1.tipologia=tipo
WHERE u1.username=user AND is_mod(user_mod)=1;
