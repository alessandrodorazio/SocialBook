CREATE PROCEDURE query2()
SELECT p.*, group_concat(a.cognome) AS autori
FROM Pubblicazione p, Autore a, Autore_Pubblicazione ap
WHERE ap.pubblicazione=p.isbn AND ap.autore=a.id
GROUP BY p.isbn
ORDER BY data_pubblicazione DESC
LIMIT 10;
