CREATE PROCEDURE query5(user char(128))
SELECT titolo
FROM Utente u, Storia s, Pubblicazione p
WHERE s.utente=u.username AND s.pubblicazione=p.isbn AND u.username=user AND s.frase="Inserimento pubblicazione"
ORDER BY titolo;
