CREATE PROCEDURE query3()
SELECT p.*, group_concat(concat(a.nome," ",a.cognome)) AS autori
FROM Pubblicazione p, Storia s, Autore a, Autore_Pubblicazione ap
WHERE data_modifica>=DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY) AND s.pubblicazione=p.isbn AND ap.autore=a.id AND ap.pubblicazione=p.isbn
ORDER BY data_modifica DESC;
