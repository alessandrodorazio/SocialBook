CREATE PROCEDURE query18(isbn char(13))

SELECT p.*
FROM Autore_Pubblicazione ap, Pubblicazione p
WHERE pubblicazione!=isbn AND ap.pubblicazione=p.isbn
GROUP BY pubblicazione
HAVING group_concat(ap.autore) IN (
SELECT group_concat(autore) AS c FROM Autore_Pubblicazione ap2 WHERE pubblicazione=isbn GROUP BY pubblicazione);
