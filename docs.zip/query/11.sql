CREATE PROCEDURE query11 (pubblicazione char(13), username char(128))

INSERT INTO Recensione (pubblicazione, utente,mi_piace,descrizione) VALUES (pubblicazione, username, 1, "");
