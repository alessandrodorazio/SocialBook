CREATE PROCEDURE query17()

SELECT r.pubblicazione, MAX(data_ristampa)
FROM Ristampe r
GROUP BY r.pubblicazione;
