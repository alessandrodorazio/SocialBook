CREATE PROCEDURE Accesso (email char(128), password char(128))
SELECT username, tipologia
FROM Utente u
WHERE u.email=email AND u.password=PASSWORD(password);
