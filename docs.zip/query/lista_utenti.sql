CREATE PROCEDURE lista_utenti()
SELECT username
FROM Utente;
