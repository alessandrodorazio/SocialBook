CREATE PROCEDURE query6()
SELECT p.titolo, p.isbn, group_concat( concat(a.nome, " ", a.cognome) ) AS autori, e.nome AS editore, p.data_pubblicazione
FROM Pubblicazione p, Autore a, Autore_Pubblicazione ap, Editore e
WHERE ap.autore=a.id AND ap.pubblicazione=p.isbn AND e.id=p.editore
GROUP BY p.isbn
ORDER BY p.titolo;
