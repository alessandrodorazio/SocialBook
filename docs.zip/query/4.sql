CREATE PROCEDURE query4()

SELECT username, COUNT(*) AS tot
FROM Storia s, Utente u
WHERE s.utente=u.username AND s.frase="Inserimento pubblicazione"
GROUP BY username
ORDER BY tot;
