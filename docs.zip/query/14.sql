CREATE procedure query14()

SELECT *
 FROM Recensione
 WHERE approvata=FALSE;
