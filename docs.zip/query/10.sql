CREATE PROCEDURE query10(nome_utente char(128), pubbl char(13), moderatore char(128))
UPDATE Recensione
SET approvata=1
WHERE utente=nome_utente AND pubblicazione=pubbl AND is_mod(moderatore)>0;
